package com.autocutai.app

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.MediaItem
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File
import java.io.FileInputStream

class MainActivity : Activity() {
    private var selectedVideo: Uri? = null
    private var transformer: Transformer? = null
    private lateinit var status: TextView
    private lateinit var startInput: EditText
    private lateinit var endInput: EditText
    private lateinit var exportButton: Button
    private lateinit var progress: ProgressBar

    private val videoPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                selectedVideo = uri
                status.text = "ভিডিও নির্বাচন করা হয়েছে। চাইলে Start/End সময় দিয়ে কাটতে পারো।"
                exportButton.isEnabled = true
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 36, 28, 24)
            setBackgroundColor(0xFF10121B.toInt())
        }

        val title = TextView(this).apply {
            text = "AutoCut AI"
            textSize = 30f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        page.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "Your personal video editor • Prototype 0.1"
            textSize = 14f
            setTextColor(0xFFB8BBD0.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 28)
        }
        page.addView(subtitle, matchWrap())

        val pickButton = makeButton("1. Select a video")
        pickButton.setOnClickListener {
            videoPicker.launch(arrayOf("video/*"))
        }
        page.addView(pickButton, matchWrap())

        startInput = makeInput("Start time in seconds (default 0)")
        page.addView(startInput, matchWrap())

        endInput = makeInput("End time in seconds (blank = full video)")
        page.addView(endInput, matchWrap())

        exportButton = makeButton("2. Auto Edit & Export MP4")
        exportButton.isEnabled = false
        exportButton.setOnClickListener { exportVideo() }
        page.addView(exportButton, matchWrap())

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            visibility = ProgressBar.GONE
        }
        page.addView(progress, matchWrap())

        status = TextView(this).apply {
            text = "একটি ভিডিও নির্বাচন করে শুরু করো।"
            textSize = 15f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 12)
        }
        page.addView(status, matchWrap())

        val note = TextView(this).apply {
            text = "এই প্রথম প্রোটোটাইপ ভিডিও নির্বাচন, ট্রিম ও MP4 এক্সপোর্টের ভিত্তি তৈরি করে। AI scene detection, music matching ও multi-clip montage পরের ধাপে যোগ হবে।"
            textSize = 13f
            setTextColor(0xFFB8BBD0.toInt())
            gravity = Gravity.CENTER
        }
        page.addView(note, matchWrap())

        setContentView(page)
    }

    private fun matchWrap(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = 14 }

    private fun makeButton(label: String) = Button(this).apply {
        text = label
        isAllCaps = false
    }

    private fun makeInput(hintText: String) = EditText(this).apply {
        hint = hintText
        setHintTextColor(0xFF9A9DB2.toInt())
        setTextColor(0xFFFFFFFF.toInt())
        textSize = 14f
        setSingleLine(true)
        inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
    }

    private fun exportVideo() {
        val uri = selectedVideo ?: return
        val startSeconds = startInput.text.toString().toDoubleOrNull() ?: 0.0
        val endSeconds = endInput.text.toString().toString().toDoubleOrNull()

        if (startSeconds < 0 || (endSeconds != null && endSeconds <= startSeconds)) {
            Toast.makeText(this, "Start/End সময় ঠিক করে দাও।", Toast.LENGTH_LONG).show()
            return
        }

        val mediaBuilder = MediaItem.Builder().setUri(uri)
        val clipEnd = endSeconds
        if (clipEnd != null) {
            mediaBuilder.setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs((startSeconds * 1000).toLong())
                    .setEndPositionMs((clipEnd * 1000).toLong())
                    .build()
            )
        } else if (startSeconds > 0) {
            Toast.makeText(
                this,
                "Trim করতে End time-ও দাও। পুরো ভিডিও এক্সপোর্ট করতে Start 0 রাখো।",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        val editedItem = EditedMediaItem.Builder(mediaBuilder.build()).build()
        val output = File(cacheDir, "autocut_export_${System.currentTimeMillis()}.mp4")
        exportButton.isEnabled = false
        progress.progress = 0
        progress.visibility = ProgressBar.VISIBLE
        status.text = "ভিডিও প্রসেস হচ্ছে… ফোনের ক্ষমতা ও ভিডিওর দৈর্ঘ্য অনুযায়ী সময় লাগবে।"

        val listener = object : Transformer.Listener {
            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                try {
                    val savedUri = copyToGallery(output)
                    status.text = "Export complete! ভিডিও Gallery/Movies-এ সেভ হয়েছে।"
                    Toast.makeText(this@MainActivity, "ভিডিও সেভ হয়েছে", Toast.LENGTH_LONG).show()
                    if (savedUri != null) {
                        val share = Intent(Intent.ACTION_SEND).apply {
                            type = "video/mp4"
                            putExtra(Intent.EXTRA_STREAM, savedUri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        // Sharing is optional; the exported file is already saved.
                    }
                } catch (e: Exception) {
                    status.text = "Export হয়েছে, কিন্তু Gallery-তে সেভ করা যায়নি: ${e.message}"
                } finally {
                    progress.visibility = ProgressBar.GONE
                    exportButton.isEnabled = true
                    output.delete()
                    transformer = null
                }
            }

            override fun onError(
                composition: Composition,
                exportResult: ExportResult,
                exportException: ExportException
            ) {
                status.text = "Export ব্যর্থ: ${exportException.message ?: "ভিডিও ফরম্যাট সাপোর্ট নাও করতে পারে"}"
                progress.visibility = ProgressBar.GONE
                exportButton.isEnabled = true
                output.delete()
                transformer = null
            }
        }

        transformer = Transformer.Builder(this)
            .addListener(listener)
            .build()
        transformer?.start(editedItem, output.absolutePath)
    }

    private fun copyToGallery(source: File): Uri? {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "AutoCut_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/AutoCutAI")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
        }
        val resolver = contentResolver
        val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val target = resolver.insert(collection, values) ?: return null
        try {
            resolver.openOutputStream(target)?.use { outputStream ->
                FileInputStream(source).use { inputStream ->
                    inputStream.copyTo(outputStream)
                }
            } ?: throw IllegalStateException("Output stream খুলতে পারিনি")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val done = ContentValues().apply {
                    put(MediaStore.Video.Media.IS_PENDING, 0)
                }
                resolver.update(target, done, null, null)
            }
            return target
        } catch (e: Exception) {
            resolver.delete(target, null, null)
            throw e
        }
    }
}
